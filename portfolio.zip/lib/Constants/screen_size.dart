const double kMinDesktopWidth = 600.0;
const double kMedDesktopWidth = 800.0;
