class SnsLinks {
  static const String github = "https://github.com/Lubna-Mehboob";
  static const String linkedIn = "https://www.linkedin.com/in/lubna995/";
  static const String facebook = "https://web.facebook.com/?_rdc=1&_rdr#";
}
