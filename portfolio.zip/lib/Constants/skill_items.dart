const List<Map> platformItems = [
  {
    'img': 'lib/assets/icons/android_icon.png',
    'title': 'Android Dev',
  },
  {
    'img': 'lib/assets/icons/web_icon.png',
    'title': 'Web Dev',
  },
];

const List<Map> skillItems = [
  {
    'img': 'lib/assets/icons/flutter.png',
    'title': 'Flutter',
  },
  {
    'img': 'lib/assets/icons/dart.png',
    'title': 'Dart',
  },
  {
    'img': 'lib/assets/icons/html5.png',
    'title': 'HTML',
  },
  {
    'img': 'lib/assets/images/excel.png',
    'title': 'Excel',
  },
  {
    'img': 'lib/assets/images/c-.png',
    'title': 'C++',
  },
];
