import 'package:flutter/material.dart';

List<String> navTitles = [
  'Home',
  'Skills',
  'Projects',
  'Contact',
  'Blog',
];
List<IconData> navIcons = [
  Icons.home,
  Icons.handyman_outlined,
  Icons.apps,
  Icons.quick_contacts_mail,
  Icons.web,
];
